#!/bin/bash

echo "Descargando dockerTracer";

eval `ssh-agent -s`

ssh-add dockerTracer

git clone git@github.com:Mejia1994/dockertracer.git #/var/www/html/dockerTracer
