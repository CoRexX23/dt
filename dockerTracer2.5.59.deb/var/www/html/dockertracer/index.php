<?php
include_once 'config.php';
include_once 'libs/paf.php';

$router = new PAF();
$router->setCorsEnabled(true);

$app = new appService();
$proyectoService = new proyectoService();
$dockerService = new dockerService();

$router->renderView(['/', '/index', '/index/'], function () use ($app) {
    return file_get_contents('app/app.html');
});

$router->map('GET', '/proyectoService/listarProyectos/', function ($request) use ($proyectoService) {
    $lista = $proyectoService->listarProyectos();
    return $lista;
});

$router->map('POST', '/proyectoService/eliminarProyecto/', function ($request) use ($proyectoService) {
    $codigoProyecto = $_POST['codigo'];

    $proyectos = $proyectoService->eliminarProyecto($codigoProyecto);
    return $proyectos;
});

$router->map('POST', '/proyectoService/cargarProyecto/', function ($request) use ($proyectoService) {
    $codigoProyecto = $_POST['codigo'];

    $proyectos = $proyectoService->cargarProyecto($codigoProyecto);
    return $proyectos;
});

$router->map('POST', '/proyectoService/guardarProyecto/', function ($request) use ($proyectoService) {
    $proyectoService->guardarProyecto();
});

$router->map('POST', '/proyectoService/abrirContenedores/', function ($request) use ($proyectoService) {
    $proyectoService->abrirContenedores();
});

$router->map('POST', '/proyectoService/cargarContenedor', function ($request) use ($proyectoService) {
    $proyectoService->cargarContenedor();
});

$router->map('POST', '/proyectoService/crearProyecto/', function ($request) use ($proyectoService) {
    $proyectoService->crearProyecto();
});

$router->map('POST', '/dockerService/iniciar_shellinabox', function ($request) use ($dockerService) {
    $dockerService->iniciar_shellinabox();
});

$router->execute();
