<?php

class appService
{
    function index()
    {
        Mustache_Autoloader::register();
        $view = new Mustache_Engine(
            array(
                'charset' => 'UTF-8',
                'template_class_prefix' => '__MUSTACHE_',
                'loader' => new Mustache_Loader_FilesystemLoader('app/plantillas')
            )
        );
        $arr = array(
            'css' => array(
                'public/css/bootstrap.min.css',
                'public/css/jquery.qtip.min.css',
                'public/css/jquery.alerts.css',
                'app/css/app.css',
                'public/css/context-menus.css',
                'public/css/jquery-ui.css',
                'public/css/windows.min.css',
                'public/modal/modal.css'
            ),
            'app_name' => app_name,
            'js' => array(
                'public/js/022a1c9fd2.js',
                'public/js/jquery-3.3.1.min.js',
                'public/js/mustache.min.js',
                'public/js/bootstrap.min.js',
                'public/js/popper.min.js',
                'public/js/jAlert.min.js',
                'public/js/cytoscape.min.js',
                'public/js/context-menus.js',
                'public/js/cytoscape-qtip.js',
                'public/js/jquery.qtip.min.js',
                'public/js/jquery-ui.js',
                'public/js/terminales.min.js',
                'app/js/cy.js',
                'app/js/peticiones.js',
                'public/modal/modal.js',
                'app/js/app.js'
            )
        );

        echo $view->render('app', $arr);
        $obj = new dockerService();
        $obj->iniciar_contenedores();
    }

}
