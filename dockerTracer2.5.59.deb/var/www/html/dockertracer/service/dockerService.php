<?php

class dockerService
{
    //** si id contenedor es 0 los obtendra a todos los contenedores */
    //** los id_excluidos son los que estan en los proyectos */
    public function listar_contenedores($id_contenedor = "", $excluidos = array())
    {
        $container_list = shell_exec("docker ps -a | awk '{ print $1,$2,\$NF }' | sed '1d' ");
        $arr = explode("\n", $container_list);

        $retorno = array();
        foreach ($arr as $elm) {
            if ($elm != null) {
                $value = explode(" ", $elm);
                $retorno[$value[0]] = array(
                    "id" => $value[0],
                    "image" => $value[1],
                    "name" => $value[2],
                    "type" => "container",
                    "activo" => (!isset($excluidos[$value[0]])) ? true : false
                );
            }
        };

        $datos = array();
        if ($id_contenedor != "") {
            $datos = $this->info_contenedor($id_contenedor, $retorno[$id_contenedor]);
        } else {
            foreach ($retorno as $key => $value) {
                $datos[] = $this->info_contenedor($key, $value);
            }
        }


        return $datos;
    }

    private function info_contenedor($id_contenedor, $data)
    {
        $elm = json_decode(shell_exec("docker inspect $id_contenedor"), true)[0];
        //  shell_exec("docker start $id_contenedor");

        foreach ($elm["NetworkSettings"]["Networks"] as $key => $value) {
            $info = $this->info_redes($value["NetworkID"]);

            $data['net'][] = array(
                "id" => $value['NetworkID'],
                "name" => $key,
                "driver" => $info['driver'],
                "subnet" => $info['network'][0]["Subnet"],
                "ipaddress" => (isset($value['IPAddress'])) ? $value['IPAddress'] : 0,
                "prefix" => (isset($value['IPPrefixLen'])) ? $value['IPPrefixLen'] : 0,
                "gateway" => (isset($value["Gateway"])) ? $value["Gateway"] : 0,
                "type" => "network"
            );
        }

        return $data;
    }

    private function info_redes($id_red)
    {
        $network = shell_exec("docker network list  | awk '{print $2}' | sed '1d' ");
        $network = $this->formato_texto($network);
        $res = json_decode(shell_exec("docker network inspect $network"), true);

        $retorno = array();
        foreach ($res as $item) {
            $retorno[$item["Id"]] = array(
                "id" => $item["Id"],
                "name" => $item["Name"],
                "driver" => $item["Driver"],
                "network" => $item["IPAM"]["Config"],
                "type" => "network"
            );
        }

        return $retorno[$id_red];
    }


    public function iniciar_contenedores($container_list)
    {
        $arr = implode(" ", $container_list);
        shell_exec("docker start $arr");
    }

    public function iniciar_shellinabox()
    {
        $id_contendor = $_POST['id_contenedor'];
        $comando = "docker exec $id_contendor /etc/init.d/shellinabox start >> log.txt";
        $ultima_linea = passthru($comando, $retval);

        echo json_encode(array('data' => $ultima_linea, 'mensaje' => 'Terminal inicada.', 'respuesta' => true));
    }

    private function formato_texto($cadena)
    {
        $buscar = array(chr(13) . chr(10), "\r\n", "\n", "\r");
        $reemplazar = array(" ", " ", " ", " ");
        $cadena = str_ireplace($buscar, $reemplazar, $cadena);
        return $cadena;
    }
}
