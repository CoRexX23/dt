<?php

/** @property dockerService dockerService.php */
class proyectoService
{
    public function crearProyecto()
    {
        try {

            if (!isset($_POST['info']['nombreProyecto']))
                throw new \libs\BasicException\UserMessageException('no se envio el nombre del preyecto.');

            $nombre = $_POST['info']['nombreProyecto'];
            $file = proyect_path . $nombre . file_type;

            if (file_exists($file))
                throw new \libs\BasicException\UserMessageException("Ya existe un proyecto con ese nombre.");

            $data = array(
                'info' => [
                    'nombreProyecto' => $_POST['info']['nombreProyecto'],
                    'zoomLevel' => (int)$_POST['info']['zoomLevel'],
                    'panLevel' => [
                        'x' => (int)$_POST['info']['panLevel']['x'],
                        'y' => (int)$_POST['info']['panLevel']['y']
                    ],
                ]
            );

            $fopen = fopen($file, "w");
            $saved = fwrite($fopen, json_encode($data, 128));
            fclose($fopen);

            if ($fopen == false || $saved == false)
                throw new  \libs\BasicException\UserMessageException("No se pudo crear el proyecto.");

            $this->response(null, "Proyecto creado.", true);
        } catch (\libs\BasicException\UserMessageException $ex) {
            $this->response(null, $ex->getMessage(), false);
        }
    }

    public function guardarProyecto()
    {
        try {
            $file = proyect_path . $_POST['info']['nombreProyecto'] . file_type;

            foreach ($_POST['nodos'] as &$elm) {
                $elm['position']['x'] = (int)$elm['position']['x'];
                $elm['position']['y'] = (int)$elm['position']['y'];
            }

            $data = array(
                'info' => [
                    'nombreProyecto' => $_POST['info']['nombreProyecto'],
                    'zoomLevel' => (int)$_POST['info']['zoomLevel'],
                    'panLevel' => [
                        'x' => (int)$_POST['info']['panLevel']['x'],
                        'y' => (int)$_POST['info']['panLevel']['y']
                    ],
                ],
                'nodos' => $_POST['nodos']
            );

            if (!file_exists($file))
                throw new \libs\BasicException\UserMessageException("No existe el proyecto al que esta accediendo.");

            $fopen = fopen($file, "w");
            $fwite = fwrite($fopen, json_encode($data, 128));
            fclose($fopen);

            if ($fopen == false || $fwite == false)
                throw new \libs\BasicException\UserMessageException("No se pudo guardar los datos.");

            $this->response(null, "Datos guardados", true);
        } catch (\libs\BasicException\UserMessageException $ex) {
            $this->response(null, $ex->getMessage(), false);
        }
    }

    public function listarProyectos()
    {
        try {
            $dir = opendir("./proyectos");
            if ($dir == false)
                throw new \libs\BasicException\UserMessageException("Error al cargar lista de proyectos.");

            $contenido = array();
            while (($elemento = readdir($dir)) !== False) {
                if ($elemento != "." and $elemento != "..") {
                    $arr = explode(file_type, $elemento);
                    $contenido[] = array(
                        "codigo" => base64_encode($arr[0]),
                        "nombre" => $arr[0],
                        "modificado" => date("d F Y", filemtime("proyectos/$elemento"))
                    );
                }
            }
            $this->response($contenido, "correcto", true);
        } catch (\libs\BasicException\UserMessageException $ex) {
            $this->response(null, $ex->getMessage(), false);
        }
    }

    public function eliminarProyecto()
    {
        try {
            $file = proyect_path . base64_decode($_POST['codigo']) . file_type;

            if (!file_exists($file))
                throw new \libs\BasicException\UserMessageException("No existe el proyecto.", 1);

            $res = unlink($file);

            if (!$res)
                throw new \libs\BasicException\UserMessageException("No se pudo borrar el proyecto..", 1);

            $this->response(null, 'Proyecto eliminado.', true);
        } catch (\libs\BasicException\UserMessageException $e) {
            $this->response(null, $e->getMessage(), false);
        }
    }

    public function cargarProyecto($codigoProyecto)
    {
        try {
            $file = proyect_path . base64_decode($codigoProyecto) . file_type;
            if (!file_exists($file))
                throw new \libs\BasicException\UserMessageException("No existe el proyecto.", 1);

            $datos = json_decode(file_get_contents($file), true);

            $posiciones = array();
            $contenedores = array();
            $idContendores = array();

            $obj = new dockerService();
            foreach ($datos['nodos'] as $elm) {
                if ($elm['type'] == 'container') {
                    $idContendores[] = $elm['id'];
                }
            }


            $obj->iniciar_contenedores($idContendores);

            foreach ($datos['nodos'] as &$elm) {
                $posiciones[$elm["id"]] = $elm["position"];
                $contenedores[$elm["id"]] = $obj->listar_contenedores($elm["id"], array());
            }


            $retorno = array();
            foreach ($posiciones as $key => $value) {

                if (isset($contenedores[$key])) {
                    //del contenedor
                    $contenedores[$key]["posiciones"] = $value;

                    //de la network
                    if (isset($contenedores[$key]["net"])) {
                        foreach ($contenedores[$key]["net"] as &$elm) {
                            $elm["posiciones"] = $posiciones[$elm["id"]];
                        }
                    }

                    $retorno[] = $contenedores[$key];
                }
            }

            foreach ($retorno as &$elm) {
                $elm["net"] = array_values($elm["net"]);
            }

            $data = array(
                'info' => $datos['info'],
                'nodos' => $retorno
            );


            $this->response($data, "El proyecto se ha cargado.", true);
        } catch (\libs\BasicException\UserMessageException $ex) {
            $this->response(null, $ex->getMessage(), false);
        }
    }

    public function abrirContenedores()
    {
        try {
            $res = $this->contenedores_excluidos();

            $obj = new dockerService();
            $retorno = $obj->listar_contenedores(0, $res);

            $this->response($retorno, 'datos', true);
        } catch (\libs\BasicException\UserMessageException $e) {
            $this->response('', $e->getMessage(), false);
        }
    }

    public function cargarContenedor()
    {
        try {
            $ids = $_POST['ids'];
            $retorno = array();

            $obj = new dockerService();
            $obj->iniciar_contenedores($ids);

            foreach ($ids as $id) {
                $retorno[] = $obj->listar_contenedores($id, array());
            }

            $this->response($retorno, 'datos', true);
        } catch (Exception $e) {
            $this->response("", 'error', false);
        }
    }

    public function contenedores_excluidos()
    {
        try {
            $dir = opendir("./proyectos");
            if ($dir == false)
                throw new \libs\BasicException\UserMessageException("Error al cargar lista de proyectos.");

            $retorno = array();
            while (($elemento = readdir($dir)) !== False) {
                if ($elemento != "." and $elemento != "..") {
                    $tmp = json_decode(file_get_contents(proyect_path . "$elemento"), true);
                    foreach ($tmp['nodos'] as $value) {
                        $retorno[$value['id']] = $value['id'];
                    }
                }
            }

            return $retorno;
        } catch (\libs\BasicException\UserMessageException $e) {
            throw new \libs\BasicException\UserMessageException($e->getMessage());
        }
    }

    private function response($data, $mensjae, $respuesta)
    {
        $obj = new stdClass();
        $obj->data = $data;
        $obj->mensaje = $mensjae;
        $obj->respuesta = $respuesta;
        echo json_encode($obj, true);
    }
}
