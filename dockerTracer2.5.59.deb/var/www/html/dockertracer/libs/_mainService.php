<?php

class mainService
{

    private $_url = null;
    private $_url_size = 0;
    private $_extra_params = array();

    private $_error_file;
    private $_default_service_name;
    private $_default_service_method;


    public function init()
    {
        $this->_setDefaults();
        $this->_getUrl();
        $this->_load();
    }

    private function _setDefaults()
    {
        $this->_error_file = defined('ERROR_FILE') ? ERROR_FILE : 'error';
        $this->_default_service_name = default_Service;
        $this->_default_service_method = default_Method_Service;
    }


    private function _load()
    {
        try {
            $controller = $this->_getController();
            /**@var Controller $controller */

            $method = $this->_getMethod();
            $url_args = $this->_getArguments();
            $controller->__load($method, $url_args, $this->_extra_params);

        } catch (BasicException $e) {
            $this->_url[0] = $this->_error_file;
            $this->_url[1] = $this->_default_service_method;
            $url = isset($_GET['url'])? $_GET['url'] : array();
            $this->_extra_params = array_merge(array('_url' => $url), $e->getArgs());
            $this->_load();
        }

    }

    /**
     * Fetches the $_GET from 'url'
     */
    private function _getUrl()
    {
        $url = isset($_GET['url']) ? $_GET['url'] : null;

        $url = rtrim($url, '/');
        $url = filter_var($url, FILTER_SANITIZE_URL);
        $this->_url = explode('/', $url);
        $this->_url_size = count($this->_url);
    }

    private function _getController()
    {
        $controller_name = (!empty($this->_url[0])) ? $this->_url[0] : $this->_default_service_name;
       // $controller_name .= $this->_controller_sufix;
        return new $controller_name();
    }

    private function _getMethod()
    {
        return empty($this->_url[1]) ? $this->_default_service_method : $this->_url[1];
    }

    private function _getArguments()
    {
        $args = array();
        for ($i = 2; $i < $this->_url_size; $i++) {
            $args[] = $this->_url[$i];
        }
        return $args;
    }

}