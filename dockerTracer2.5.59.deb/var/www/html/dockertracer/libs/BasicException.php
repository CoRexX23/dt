<?php
namespace libs\BasicException;
use Exception;

class BasicException extends Exception{

    private $args;
    /**
     * BasicException constructor.
     */
    public function __construct($message='',$args=array())
    {
        parent::__construct($message);
        $this->args =$args;
    }

    public function getArgs(){
        return $this->args;
    }
}

/*Excepciones para mostrarle al usuario como mensaje*/
class UserMessageException extends BasicException
{
}

/*Redireccionamiento*/
class HeaderRedirectException extends BasicException
{
}

class ClassNotFoundException extends BasicException
{
}

class InvalidUrlException extends BasicException{

}
