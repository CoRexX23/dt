<?php

class Service
{

    public function __load($metodo, $parametros_url, $parametros)
    {
        try {
            $this->_validar_llamada($metodo, $parametros_url);
            $this->parametros = $parametros;
            call_user_func_array(array($this, $metodo), $parametros_url);
        } catch (\libs\BasicException\InvalidUrlException $e) {
            echo $e->getMessage();
        } catch (\libs\BasicException\UserMessageException $e) {
            echo $e->getMessage();
        }
    }

    private function _validar_llamada($metodo, $parametros_url)
    {
        $ref = new ReflectionObject($this);
        if ($ref->hasMethod($metodo)) {
            $m = $ref->getMethod($metodo);
            if ($m->isPublic() == false OR $m->getNumberOfRequiredParameters() > sizeof($parametros_url))
                throw new \libs\BasicException\UserMessageException();
        } else
            throw new libs\BasicException\InvalidUrlException();
    }
}