var modal;
$(function () {
    modal = (function () {
        var opciones = {
            plantilla: null,
            contenido: 'Para mostrar contenido personalizado debe agregar la propiedad contenido en el objeto pasado como parametro en el metodo show.',
            title: false,
            size: {
                small: 'modal-sm',
                large: 'modal-lg',
                extraLarge: 'modal-xl'
            }
        };

        function init() {
            $.get('/public/modal/modal.mst', function (res) {
                opciones.plantilla = $(res).filter('#modalContenido').html();

                $('body').on('hidden.bs.modal', '.modal', function (e) {
                    $('body').find('.modal').remove();
                })
            });
        }

        function show(obj) {
            var contenido = (typeof obj.contenido == "undefined") ? opciones.contenido : obj.contenido;
            var size = (typeof obj.size == "undefined") ? opciones.size.small : opciones.size[obj.size];
            var title = (typeof obj.title == "undefined") ? opciones.title : obj.title;

            $('body').append(Mustache.render(opciones.plantilla, {
                contenido: contenido,
                title: title,
                size: size
            }));
            $('.modal').modal('show');
        }

        function hide() {
            $('.modal').modal('hide');
        }

        return {
            init: init,
            show: show,
            hide: hide
        }
    })();
    modal.init();
});
