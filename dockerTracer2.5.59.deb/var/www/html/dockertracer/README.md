# dockertracer

1 - Entrar a /etc/hosts y agregar la siguiente linea:
    127.0.0.1 app.dockertracer
  
2 - Crear un host virtual con la configuracion descrita a continuacion:
    ServarName app.dockertracer
    DocumentRoot /var/www/html/dockertracer/

3 - Habilitar el sitio creado :
    a2ensite dockertracer

4 - agregar al grupo docker al usuario www-data 
    usermod -a -G docker www-data

5- dar permisos 766 al direcctorio /var/www/html/dockertracer/proyectfiles

6- Habilitar el modo de escritura de apache.
