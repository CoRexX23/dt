//iniciar cy object
var plantilla;
var terminales = [];

$.get('/app/plantillas/modales.mst', function(template) {
    plantilla = template;
});

const cy = cytoscape({
    container: document.getElementById('app'),
    elements: [],
    style: [{
            selector: 'node',
            style: {
                'active-bg-color': 'white',
                'shape': 'circle',
                'background-color': 'white',
                'label': 'data(name)',
            },
        },
        {
            selector: 'node[type="container"]',
            style: {
                'background-image': ['public/image/pc.png'],
                'background-fit': 'cover',
                'background-image-opacity': 0.5,
            },
        },
        {
            selector: 'node[type="network"]',
            style: {
                'background-image': ['public/image/red.jpg'],
                'background-fit': 'cover',
                'background-image-opacity': 0.5,
            },
        },
        {
            selector: 'edge',
            style: {
                'width': 2,
                'text-color': '#ccc',
                'line-color': '#ccc',
                'target-arrow-color': '#ccc',
                'target-arrow-shape': 'triangle',
            },
        },
    ],

    layout: {
        name: 'preset',
        rows: 1,
    },

    // initial viewport state:
    zoom: 1.0,
    pan: {
        x: 0,
        y: 0,
    },

    // interaction options:
    minZoom: 1,
    maxZoom: 2,
    zoomingEnabled: true,
    userZoomingEnabled: true,
    panningEnabled: true,
    userPanningEnabled: true,
    boxSelectionEnabled: false,
    selectionType: 'single',
    touchTapThreshold: 8,
    desktopTapThreshold: 4,
    autolock: false,
    autoungrabify: false,
    autounselectify: false,

    // rendering options:
    headless: false,
    styleEnabled: true,
    hideEdgesOnViewport: false,
    hideLabelsOnViewport: false,
    textureOnViewport: false,
    motionBlur: false,
    motionBlurOpacity: 0.2,
    wheelSensitivity: 1,
    pixelRatio: 'auto',
});

/**
 * Declarando menu contextual
 */

cy.contextMenus({
    menuItems: [{
            id: 'eliminar',
            content: "<i class='fa fa-trash'></i><strong>&nbspEliminar</strong>",
            selector: "node[type='container']",
            onClickFunction: function(event) {
                var target = event.target || event.cyTarget;
                var id = target.data('id');

                if (terminales[id] != undefined) {
                    terminales[id].dispose();
                    $(`#btn_${id}`).remove();

                    terminales = terminales.filter((x) => {
                        return x != id;
                    });
                }

                target.remove();
            },
            hasTrailingDivider: true,
        },
        {
            id: 'terminal',
            content: "<i class='fa fa-terminal'></i><strong>&nbspTerminal</strong>",
            selector: "node[type='container']",
            onClickFunction: function(event) {
                var target = event.target || event.cyTarget;
                var id = target.data('id');
                var ip = target.data('redes')[0]['ipaddress'];
                var nombre = target.data('name');

                //let y = cy.$(`#${id}`).position('y');
                //let x = cy.$(`#${id}`).position('x');

                if ($('body').find(`#terminal_${id}`).length == 0) {
                    $.post('/dockerService/iniciar_shellinabox', { id_contenedor: id }, function(res) {
                        if (res['respuesta'] == true) {
                            var tmp = $(plantilla).filter('#terminal').html();
                            var contenido = Mustache.render(tmp, { ip, id, nombre });
                            $('body').append(contenido);

                            setTimeout(function() {

                                $('body').find(`#terminal_${id}`).closest('div.window').css({
                                    top: 150,
                                    left: 250
                                });
                            }, 1);
                        }
                    }).fail(function() {
                        Metro.dialog.create({
                            title: "<i class='fa fa-info-circle' aria-hidden='true'></i> Aviso",
                            content: "Ha ocurrido un error al abrir la terminal, verifique que el contenedor tiene instalado <strong>shellinthebox</strong>.",
                            closeButton: true
                        });
                    });
                } else {

                    $('body').find(`#terminal_${id}`).closest('div.window').removeClass('minimized');
                    $('body').find(`#terminal_${id}`).closest('div.window').css({ 'top': 150, 'left': 250 });
                }


                /*  if (res['respuesta'] == true) {
                              var win = new Window(`${nombre}@${ip}`, {
                                  state: WindowState.NORMAL,
                                  size: {
                                      width: 500,
                                      height: 250
                                  },
                                  selected: true,
                              });

                              win.content.id = id;
                              terminales[id] = win;

                              var tmp = $(plantilla).filter('#terminalContent').html();
                              var contenido = Mustache.render(tmp, {ip: ip});
                              $(win.content).html(contenido);
                          }else {
                              jAlert(res['mensaje']);
                              return false;
                          }*/
                /* win = new Window("Title", {
                     state: WindowState.NORMAL,
                     size: {
                         width: 500,
                         height: 250
                     },
                     selected: true,
                 });

                 win.content.id = "mycontent";
                 win.content.innerHTML = 'Lorem ipsum dolor sit amet, con';
 */
                // if (terminales[id] == undefined) {

                //  terminales[id] = id;


                /*$("body").on("click", '.window_button_minimize', function (e) {
                    var id = $(this).closest('div.window_selected').find("div.window_content").attr('id');

                    var ip = cy.$(`#${id}`).data('redes')[0]["ipaddress"];
                    var nombre = cy.$(`#${id}`).data('name');

                    if ($(`#btn_${id}`).length == 0) {
                        var terminal = $('<button/>', {
                            text: `${nombre}@${ip}`,
                            id: `btn_${id}`,
                            class: "btn btn-terminal"
                        }).append($('<i/>', {
                            class: 'fa fa-window-maximize'
                        }));

                        $('#terminalesTabs').append(terminal);
                        terminal.on("click", function () {
                            terminales[id].show();
                            $(this).remove();
                        });
                    }
                });

                $("body").on('click', '.window_button_close', function (e) {
                    e.preventDefault();
                    var id = $(this).closest('div.window_selected').find("div.window_content").attr('id');

                    if (terminales[id] != undefined)
                        terminales[id].dispose();

                    terminales = terminales.filter((elm) => {
                        return elm != id
                    });
                });*/

                /* } else {
                     $(`#btn_${id}`).remove();
                     terminales[id].show();
                 }*/

            },
            hasTrailingDivider: true,
        },
    ],
    menuItemClasses: ['custom-menu-item'],
    contextMenuClasses: ['custom-context-menu'],
});

//eventos
cy.on('mouseover', 'node', function(e) {
    var node = event.target;
    node.style.cursor = 'grab';
});

cy.on('mouseout', 'node', function(e) {
    var node = event.target;
    node.style.cursor = 'default';
});


cy.on('mouseover', 'node[type="network"]', function(event) {
    var node = event.target;
    var data = node.data;
    var templete = $(plantilla).filter('#tooltip_redes').html();

    var data = {
        nombre: node.data('name'),
        driver: node.data('driver'),
        subnet: node.data('subnet'),
    };

    var contenido = Mustache.render(templete, {
        datos: data,
    });

    node.qtip({
        content: contenido,
        show: {
            event: event.type,
            ready: true,
        },
        hide: {
            event: 'mouseout unfocus',
        },
        style: {
            classes: 'qtip-dark',
        },
    }, event);
});

cy.on('mouseover', 'node[type="container"]', function(event) {
    var node = event.target;
    var data = node.data;
    var templete = $(plantilla).filter('#tooltip_contenedor').html();

    var data = {
        nombre: node.data('name'),
        imagen: node.data('image'),
        redes: node.data('redes'),
    };

    var contenido = Mustache.render(templete, {
        datos: data,
    });

    node.qtip({
        content: contenido,
        show: {
            event: event.type,
            ready: true,
        },
        hide: {
            event: 'mouseout unfocus',
        },
        style: {
            classes: 'qtip-dark',
        },
    }, event);
});