$(function() {
    var app = (function() {
        var dom = {
            nuevo_proyecto: null,
            plantilla: null,
            guardarProyecto: null,
            listarProyectos: null,
            agregarContenedor: null
        };

        const init = () => {
            setDom();
            setEvent();
            setEventModal();
        };

        const setDom = () => {
            $.get('/app/plantillas/modales.mst', function(template) {
                dom.pantilla = template;
            });

            dom.nuevo_proyecto = $('#nuevop');
            dom.guardarProyecto = $('#guardarProyecyo');
            dom.listarProyectos = $('#btn_abrir_proyecto');
            dom.agregarContenedor = $('#addc');
        };

        const setEvent = () => {

            $('body').on("click", "#descargarDiagrama", function functionName() {

                //todo verificar si hay un proyecto...
                var jpg64 = cy.jpg({
                    full: true,
                    bg: 'white',
                    scale: 20
                });


                if (jpg64 != 'data:,') {
                    //window.open(jpg64, 'dockerTracer');

                    var link = document.createElement("a");
                    link.download = $("#nombreProyectoText").text();
                    link.target = "_blank";

                    // Construct the URI
                    link.href = jpg64;
                    document.body.appendChild(link);
                    link.click();

                    // Cleanup the DOM
                    document.body.removeChild(link);
                    delete link;
                }
            });

            $("a").on('click', function(e) {
                e.preventDefault();
            });

            dom.nuevo_proyecto.on('click', function(e) {

                let temp = $(dom.pantilla).filter("#nuevoProyecto").html();
                let render = Mustache.render(temp, {});

                picoModal({
                    content: render,
                    closeButton: false
                }).show();

            });


            $("body").on("click", "#zoomout", function() {
                if (cy.zoom() > cy.minZoom()) {
                    let x = cy.zoom();
                    cy.zoom(x - 0.1);
                }
            });

            $("body").on("click", "#zoomin", function() {
                if (cy.zoom() < cy.maxZoom()) {
                    let x = cy.zoom();
                    cy.zoom(x + 0.1);
                }
            });

            dom.guardarProyecto.on("click", function() {
                var nodos = [];
                var nombreProyecto = $.trim($("#nombreProyectoText").text());

                var info = {
                    nombreProyecto: nombreProyecto,
                    zoomLevel: cy.zoom(),
                    panLevel: cy.pan()
                };

                $(cy.nodes()).each(function(index, elm) {
                    nodos.push({
                        id: elm.id(),
                        type: elm.data().type,
                        position: elm.position()
                    });
                });

                if (nombreProyecto.length > 0)
                    peticiones.guardar_proyecto(nodos, info);
                else {
                    Metro.toast.create("No existe un proyecto abierto", null, null, "bg-red");
                }
            });

            dom.listarProyectos.on('click', function() {
                var data = peticiones.abrir_proyecto();

                if (data['respuesta'] != undefined) {
                    let temp = $(dom.pantilla).filter("#abrirProyecto").html();
                    let render = Mustache.render(temp, {
                        files: data["data"]
                    });

                    picoModal({
                        content: render,
                        closeButton: false
                    }).show();
                }
            });

            dom.agregarContenedor.on('click', function() {
                var nombre_proyecto = $.trim($("#nombreProyectoText").text());
                if (nombre_proyecto.length == 0) {
                    Metro.toast.create("No hay proyecto donde cargar los contenedores.", null, null, "bg-red");
                    return false;
                }

                var res = peticiones.abrir_contenedores();
                if (res['respuesta'] == true) {
                    let temp = $(dom.pantilla).filter("#addContenedor").html();
                    let render = Mustache.render(temp, {
                        datos: res.data
                    });

                    picoModal({
                        content: render,
                        closeButton: false
                    }).show();
                }
            });
        };

        const setEventModal = () => {
            // boton aceptar modal nuevo proyecto.
            $('body').on('click', '#btn_crearProyecto', function functionName() {
                let nombreProyecto = $.trim($("#nombreProyecto").val());

                var info = {
                    nombreProyecto: nombreProyecto,
                    zoomLevel: cy.zoom(),
                    panLevel: cy.pan()
                };

                if (nombreProyecto.length > 0) {
                    peticiones.crear_proyecto(info);
                    cy.nodes().remove();
                    eliminar_modal();

                    let r = Mustache.render($(plantilla).filter('#footer').html(), { nombreProyecto: nombreProyecto });
                    $('body').append(r);
                    cy.zoom('0');
                    cy.pan({ x: 0, y: 0 });
                } else {
                    Metro.toast.create("Ingrese el nombre del proyecto", null, null, "bg-red");
                }
            });

            $('body').on('click', '#eliminarPr', function functionName() {
                var elm = $(this).closest('.proyecto_row');
                var codigo_proyecto = $(this).closest('div').attr('data-id');

                Metro.dialog.create({
                    title: "Info",
                    content: "Desea borrar el proyecto?",
                    actions: [{
                            caption: "Aceptart",
                            cls: "js-dialog-close primary",
                            onclick: function() {
                                var response = peticiones.eliminar_proyecto(codigo_proyecto);
                                Metro.toast.create(response['mensaje'], null, null, "primary");

                                if (response['respuesta'] == true) {
                                    $(elm).remove();
                                }
                            }
                        },
                        {
                            caption: "Cancelar",
                            cls: "js-dialog-close"
                        }
                    ]
                });

                /*jConfirm(, 'Aviso', function (res) {
                    if (res == true) {
                        var response = peticiones.eliminar_proyecto(codigo_proyecto);
                        if (response['respuesta'] == true) {
                            $('.modal').modal('hide');
                            //limpiar
                        }
                    }
                });*/
            });

            $('body').on('click', '#abrirPr', function functionName() {
                let codigo_proyecto = $(this).closest('div').attr('data-id');
                let data = peticiones.cargar_proyecto(codigo_proyecto);
                let info = data['data']['info'];

                if (data['respuesta']) {

                    $('#nombreProyectoText').text(info['nombreProyecto']);

                    cy.zoom(parseInt(info['zoomLevel']));
                    cy.pan(info['panLevel']);

                    cy.nodes().remove();
                    cargarTopologia(data['data']['nodos']);
                    Metro.toast.create(info['nombreProyecto'] + ' se ha cargado', null, null, "primary");
                    eliminar_modal();

                    let r = Mustache.render($(plantilla).filter('#footer').html(), { nombreProyecto: info['nombreProyecto'] });
                    $('body').append(r);

                } else {
                    Metro.toast.create(data['mensaje'], null, null, "bg-red");
                }
            });

            $('body').on('click', '#abrir_contenedores', function functionName() {
                var ids = [];
                var elm = $("body").find('#dialogContenedores').find('input:checked');

                $(elm).each(function(index, elm) {
                    ids.push($(elm).attr("data-id"));
                });

                if (ids.length == 0) {
                    Metro.toast.create("Debe seleccionar al menos un contenedor.", null, null, "bg-red");
                    return false;
                }

                var res = peticiones.cargarContenedores(ids);
                if (res['respuesta'] == true) {
                    cargarTopologia(res['data']);

                    setTimeout(function() {
                        dom.guardarProyecto.trigger('click');
                    }, 1);
                }

                eliminar_modal();
            });
        };

        const cargarTopologia = (data) => {
            let nodo_cont = [];
            let conexiones = [];

            $(data).each(function(index, elm) {
                //contenedores
                nodo_cont.push({
                    "id": elm["id"],
                    "name": elm["name"],
                    "type": elm["type"],
                    "image": elm["image"],
                    "posiciones": elm["posiciones"],
                    "redes": elm["net"].map((item) => {
                        return {
                            nombre: item["name"],
                            ipaddress: item["ipaddress"],
                            gataway: item["gateway"],
                            prefix: item["prefix"]
                        }
                    })
                });

                for (var i = 0; i < elm["net"].length; i++) {
                    //redes
                    var id = nodo_cont.map(function(x) {
                        return x["id"];
                    });

                    if (id.indexOf(elm["net"][i]["id"]) == -1) {
                        nodo_cont.push({
                            "id": elm["net"][i]["id"],
                            "name": elm["net"][i]["name"],
                            "type": elm["net"][i]["type"],
                            "image": elm["net"][i]["image"],
                            "driver": elm["net"][i]["driver"],
                            "subnet": elm["net"][i]["subnet"],
                            "posiciones": elm["net"][i]["posiciones"]
                        });
                    }
                    //enlaces
                    conexiones.push({
                        id: elm["id"] + elm["net"][i]["id"],
                        source: elm["id"],
                        target: elm["net"][i]["id"]
                    });
                }
            });

            crear_nodo(nodo_cont);
            crear_conexion(conexiones);
        };

        const crear_nodo = (arr) => {
            try {
                $(arr).each(function(index, elm) {
                    if (cy.$id(elm["id"]).length == 0) {
                        cy.add({
                            data: elm,
                            position: elm["posiciones"]
                        });
                    }
                });
            } catch (e) {
                console.log(e);
            }
        };

        const crear_conexion = (arr) => {
            try {
                $(arr).each(function(index, elm) {
                    if (cy.$id(elm["id"]).length == 0) {
                        cy.add({
                            data: elm
                        });
                    }
                });
            } catch (e) {
                console.log(e);
            }
        };

        const eliminar_modal = () => {
            $('body').find('.pico-close').trigger('click');
            $('.pico-content').remove();
        };

        return {
            init: init
        }
    })();
    app.init();
});