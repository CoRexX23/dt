$(function() {
    window.peticiones = (function() {

        const _notifyWidth = 300;
        const notify = Metro.notify;
        notify.setup({ width: 300 });

        return {
            crear_proyecto: (info) => {
                $.ajax({
                    url: "/proyectoService/crearProyecto/",
                    method: "POST",
                    data: {
                        info: info
                    },
                    dataType: "JSON"
                }).done(function(res) {
                    let cls = res['respuesta'] ? 'grayMouse' : 'alert';

                    Metro.toast.create(res['mensaje'], null, null, cls);


                    if (res['respuesta']) {
                        $('#nombreProyectoText').text(info['nombreProyecto']);
                        $('body').find('.js-dialog-close').trigger('click');
                    }
                }).fail(function() {
                    let nombreProyecto = info[nombreProyecto];
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });
            },

            guardar_proyecto: (nodos, info) => {
                $.ajax({
                    url: "/proyectoService/guardarProyecto/",
                    method: "POST",
                    data: {
                        nodos: nodos,
                        info: info
                    },
                    dataType: 'JSON'
                }).done(function(res) {
                    let cls = (res['respuesta']) ? 'primary' : "bg-red";
                    Metro.toast.create('El proyecto se ha guardado', null, null, cls);
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });
            },

            abrir_proyecto: () => {
                var data = [];
                $.ajax({
                    url: "/proyectoService/listarProyectos/",
                    dataType: 'JSON',
                    async: false
                }).done(function(datos) {
                    data = datos
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });

                return data;
            },

            eliminar_proyecto: (codigo_proyecto) => {
                var data = [];
                $.ajax({
                    url: '/proyectoService/eliminarProyecto/',
                    method: 'POST',
                    data: {
                        codigo: codigo_proyecto
                    },
                    async: false,
                    dataType: 'JSON'
                }).done(function(res) {
                    data = res;
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });
                return data;
            },

            cargar_proyecto: (codigoProyecto) => {
                var data = {};
                $.ajax({
                    url: "/proyectoService/cargarProyecto/",
                    method: "POST",
                    data: {
                        codigo: codigoProyecto
                    },
                    async: false,
                    dataType: "JSON"
                }).done(function(res) {
                    data = res;
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });
                return data;
            },

            abrir_contenedores: () => {
                var res = {};
                $.ajax({
                    url: "/proyectoService/abrirContenedores/",
                    method: "POST",
                    data: {},
                    dataType: 'JSON',
                    async: false
                }).done(function(response) {
                    res = response;
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });

                return res;
            },

            cargarContenedores: (ids) => {
                var res = {};
                $.ajax({
                    url: "/proyectoService/cargarContenedor",
                    method: "POST",
                    async: false,
                    data: {
                        ids: ids
                    },
                    dataType: 'JSON'
                }).done(function(response) {
                    res = response;
                }).fail(function() {
                    Metro.toast.create("Ha ocurrido un error", null, null, 'bg-red');
                });
                return res;
            },
        }
    })();
});