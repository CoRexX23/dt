<?php
define("app_name","app.dockerTracer");
define("file_type", ".json");
define("proyect_path", "proyectos/");
define('default_Service', 'appService');
define('default_Method_Service', 'index');
define('URL', $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER["HTTP_HOST"] . "/");

$includes_path = array(
    "libs/mainService.php",
    "libs/Service.php",
    "libs/BasicException.php",
    "service/appService.php",
    "service/dockerService.php",
    "service/proyectoService.php",
    'libs/Mustache/Autoloader.php'
);


foreach ($includes_path as $elm) {
    if (file_exists($elm)) {
        include_once $elm;
    }
}
